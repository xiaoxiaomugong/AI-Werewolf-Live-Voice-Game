import { loadConfig } from '../lib/load-config'
export default loadConfig
