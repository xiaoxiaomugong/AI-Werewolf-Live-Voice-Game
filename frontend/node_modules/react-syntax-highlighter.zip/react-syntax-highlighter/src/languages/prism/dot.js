import dot from "refractor/lang/dot.js";;
export default dot;
