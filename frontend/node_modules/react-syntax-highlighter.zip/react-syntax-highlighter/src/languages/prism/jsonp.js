import jsonp from "refractor/lang/jsonp.js";;
export default jsonp;
