import smali from "refractor/lang/smali.js";;
export default smali;
