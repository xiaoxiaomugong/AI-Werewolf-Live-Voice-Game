import glsl from "refractor/lang/glsl.js";;
export default glsl;
