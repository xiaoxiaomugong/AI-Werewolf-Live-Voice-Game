import factor from "refractor/lang/factor.js";;
export default factor;
