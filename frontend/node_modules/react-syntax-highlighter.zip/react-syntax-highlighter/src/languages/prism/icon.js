import icon from "refractor/lang/icon.js";;
export default icon;
