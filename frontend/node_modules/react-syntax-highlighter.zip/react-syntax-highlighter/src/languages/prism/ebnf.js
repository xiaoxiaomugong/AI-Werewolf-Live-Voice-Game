import ebnf from "refractor/lang/ebnf.js";;
export default ebnf;
