import wren from "refractor/lang/wren.js";;
export default wren;
