import ejs from "refractor/lang/ejs.js";;
export default ejs;
