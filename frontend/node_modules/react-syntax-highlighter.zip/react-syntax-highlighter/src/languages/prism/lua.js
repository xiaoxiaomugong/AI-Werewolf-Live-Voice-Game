import lua from "refractor/lang/lua.js";;
export default lua;
