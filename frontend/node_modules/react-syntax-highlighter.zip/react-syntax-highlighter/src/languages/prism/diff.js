import diff from "refractor/lang/diff.js";;
export default diff;
