import sparql from "refractor/lang/sparql.js";;
export default sparql;
