import markupTemplating from "refractor/lang/markup-templating.js";;
export default markupTemplating;
