import toml from "refractor/lang/toml.js";;
export default toml;
