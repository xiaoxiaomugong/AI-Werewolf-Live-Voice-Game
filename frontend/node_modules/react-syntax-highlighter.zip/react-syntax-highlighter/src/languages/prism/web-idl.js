import webIdl from "refractor/lang/web-idl.js";;
export default webIdl;
