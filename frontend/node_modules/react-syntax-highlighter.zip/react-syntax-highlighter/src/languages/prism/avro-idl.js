import avroIdl from "refractor/lang/avro-idl.js";;
export default avroIdl;
