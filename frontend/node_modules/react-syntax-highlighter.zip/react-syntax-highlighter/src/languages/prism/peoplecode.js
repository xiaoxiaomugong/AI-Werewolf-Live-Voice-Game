import peoplecode from "refractor/lang/peoplecode.js";;
export default peoplecode;
