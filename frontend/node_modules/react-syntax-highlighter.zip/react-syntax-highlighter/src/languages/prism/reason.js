import reason from "refractor/lang/reason.js";;
export default reason;
