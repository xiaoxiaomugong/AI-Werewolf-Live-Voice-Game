import properties from "refractor/lang/properties.js";;
export default properties;
