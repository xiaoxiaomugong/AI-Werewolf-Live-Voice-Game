import monkey from "refractor/lang/monkey.js";;
export default monkey;
