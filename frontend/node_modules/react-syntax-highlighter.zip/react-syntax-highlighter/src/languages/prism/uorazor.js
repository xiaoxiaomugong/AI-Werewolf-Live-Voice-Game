import uorazor from "refractor/lang/uorazor.js";;
export default uorazor;
