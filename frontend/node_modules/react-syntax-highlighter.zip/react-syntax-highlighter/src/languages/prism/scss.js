import scss from "refractor/lang/scss.js";;
export default scss;
