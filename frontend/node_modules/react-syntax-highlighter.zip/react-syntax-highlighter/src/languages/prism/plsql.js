import plsql from "refractor/lang/plsql.js";;
export default plsql;
