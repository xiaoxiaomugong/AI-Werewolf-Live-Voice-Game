import nevod from "refractor/lang/nevod.js";;
export default nevod;
