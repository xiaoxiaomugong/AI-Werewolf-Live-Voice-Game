import idris from "refractor/lang/idris.js";;
export default idris;
