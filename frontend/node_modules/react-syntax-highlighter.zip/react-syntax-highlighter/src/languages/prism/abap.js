import abap from "refractor/lang/abap.js";;
export default abap;
