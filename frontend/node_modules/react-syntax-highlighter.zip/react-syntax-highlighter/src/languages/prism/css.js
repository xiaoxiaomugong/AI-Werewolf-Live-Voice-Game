import css from "refractor/lang/css.js";;
export default css;
