import javascript from "refractor/lang/javascript.js";;
export default javascript;
