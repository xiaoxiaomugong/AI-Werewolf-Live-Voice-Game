import keepalived from "refractor/lang/keepalived.js";;
export default keepalived;
