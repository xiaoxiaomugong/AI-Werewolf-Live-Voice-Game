import icuMessageFormat from "refractor/lang/icu-message-format.js";;
export default icuMessageFormat;
