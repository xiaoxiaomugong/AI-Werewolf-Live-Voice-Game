import neon from "refractor/lang/neon.js";;
export default neon;
