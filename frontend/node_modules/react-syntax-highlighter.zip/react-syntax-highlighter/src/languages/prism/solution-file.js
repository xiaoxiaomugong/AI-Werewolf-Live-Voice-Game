import solutionFile from "refractor/lang/solution-file.js";;
export default solutionFile;
