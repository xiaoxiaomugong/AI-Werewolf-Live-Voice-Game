import goModule from "refractor/lang/go-module.js";;
export default goModule;
