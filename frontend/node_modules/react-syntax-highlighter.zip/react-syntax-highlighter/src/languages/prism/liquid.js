import liquid from "refractor/lang/liquid.js";;
export default liquid;
