import basic from "refractor/lang/basic.js";;
export default basic;
