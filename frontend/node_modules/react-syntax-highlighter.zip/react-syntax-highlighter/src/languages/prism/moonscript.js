import moonscript from "refractor/lang/moonscript.js";;
export default moonscript;
