import tsx from "refractor/lang/tsx.js";;
export default tsx;
