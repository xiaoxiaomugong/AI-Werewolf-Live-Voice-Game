import cpp from "refractor/lang/cpp.js";;
export default cpp;
