import javadoc from "refractor/lang/javadoc.js";;
export default javadoc;
