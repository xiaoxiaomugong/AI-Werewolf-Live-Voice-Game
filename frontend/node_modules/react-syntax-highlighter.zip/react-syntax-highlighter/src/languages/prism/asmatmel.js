import asmatmel from "refractor/lang/asmatmel.js";;
export default asmatmel;
