import tcl from "refractor/lang/tcl.js";;
export default tcl;
