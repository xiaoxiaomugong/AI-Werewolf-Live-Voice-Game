import hlsl from "refractor/lang/hlsl.js";;
export default hlsl;
