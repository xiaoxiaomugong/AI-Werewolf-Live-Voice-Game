import smalltalk from "refractor/lang/smalltalk.js";;
export default smalltalk;
