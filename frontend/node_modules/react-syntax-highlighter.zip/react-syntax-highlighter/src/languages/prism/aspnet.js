import aspnet from "refractor/lang/aspnet.js";;
export default aspnet;
