import erlang from "refractor/lang/erlang.js";;
export default erlang;
