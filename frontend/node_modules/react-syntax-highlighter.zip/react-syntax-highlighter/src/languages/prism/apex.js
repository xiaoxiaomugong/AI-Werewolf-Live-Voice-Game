import apex from "refractor/lang/apex.js";;
export default apex;
