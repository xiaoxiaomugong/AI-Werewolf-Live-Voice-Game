import cfscript from "refractor/lang/cfscript.js";;
export default cfscript;
