import nix from "refractor/lang/nix.js";;
export default nix;
