import nginx from "refractor/lang/nginx.js";;
export default nginx;
