import nsis from "refractor/lang/nsis.js";;
export default nsis;
