import c from "refractor/lang/c.js";;
export default c;
