import t4Cs from "refractor/lang/t4-cs.js";;
export default t4Cs;
