import nand2tetrisHdl from "refractor/lang/nand2tetris-hdl.js";;
export default nand2tetrisHdl;
