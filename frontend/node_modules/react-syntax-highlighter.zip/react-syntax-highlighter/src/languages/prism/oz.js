import oz from "refractor/lang/oz.js";;
export default oz;
