import dhall from "refractor/lang/dhall.js";;
export default dhall;
