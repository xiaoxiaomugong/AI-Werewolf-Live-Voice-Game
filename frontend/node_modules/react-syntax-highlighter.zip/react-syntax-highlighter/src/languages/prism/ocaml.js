import ocaml from "refractor/lang/ocaml.js";;
export default ocaml;
