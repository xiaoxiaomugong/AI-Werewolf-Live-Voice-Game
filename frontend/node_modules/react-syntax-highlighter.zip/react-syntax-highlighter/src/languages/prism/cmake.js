import cmake from "refractor/lang/cmake.js";;
export default cmake;
