import lolcode from "refractor/lang/lolcode.js";;
export default lolcode;
