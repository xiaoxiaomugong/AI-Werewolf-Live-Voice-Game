import coq from "refractor/lang/coq.js";;
export default coq;
