import autohotkey from "refractor/lang/autohotkey.js";;
export default autohotkey;
