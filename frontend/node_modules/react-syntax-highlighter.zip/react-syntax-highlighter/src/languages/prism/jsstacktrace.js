import jsstacktrace from "refractor/lang/jsstacktrace.js";;
export default jsstacktrace;
