import brightscript from "refractor/lang/brightscript.js";;
export default brightscript;
