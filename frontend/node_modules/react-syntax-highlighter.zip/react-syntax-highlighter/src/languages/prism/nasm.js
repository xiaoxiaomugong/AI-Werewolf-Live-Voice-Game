import nasm from "refractor/lang/nasm.js";;
export default nasm;
