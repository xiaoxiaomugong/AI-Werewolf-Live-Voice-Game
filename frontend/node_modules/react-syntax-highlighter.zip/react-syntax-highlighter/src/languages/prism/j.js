import j from "refractor/lang/j.js";;
export default j;
