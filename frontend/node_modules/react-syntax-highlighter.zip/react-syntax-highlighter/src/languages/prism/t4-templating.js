import t4Templating from "refractor/lang/t4-templating.js";;
export default t4Templating;
