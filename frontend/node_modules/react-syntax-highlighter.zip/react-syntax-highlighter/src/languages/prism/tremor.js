import tremor from "refractor/lang/tremor.js";;
export default tremor;
