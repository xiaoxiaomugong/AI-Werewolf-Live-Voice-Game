import hsts from "refractor/lang/hsts.js";;
export default hsts;
