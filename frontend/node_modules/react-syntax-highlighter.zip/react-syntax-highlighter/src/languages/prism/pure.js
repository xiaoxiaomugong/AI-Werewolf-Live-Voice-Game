import pure from "refractor/lang/pure.js";;
export default pure;
