import graphql from "refractor/lang/graphql.js";;
export default graphql;
