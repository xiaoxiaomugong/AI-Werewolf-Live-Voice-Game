import pug from "refractor/lang/pug.js";;
export default pug;
