import apache from "highlight.js/lib/languages/apache";
export default apache;
