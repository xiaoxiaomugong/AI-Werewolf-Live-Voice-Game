import gml from "highlight.js/lib/languages/gml";
export default gml;
