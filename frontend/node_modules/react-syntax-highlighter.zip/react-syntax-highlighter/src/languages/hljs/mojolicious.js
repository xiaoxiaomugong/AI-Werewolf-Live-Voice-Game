import mojolicious from "highlight.js/lib/languages/mojolicious";
export default mojolicious;
