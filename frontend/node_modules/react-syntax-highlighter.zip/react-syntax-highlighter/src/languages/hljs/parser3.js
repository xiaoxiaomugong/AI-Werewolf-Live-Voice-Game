import parser3 from "highlight.js/lib/languages/parser3";
export default parser3;
