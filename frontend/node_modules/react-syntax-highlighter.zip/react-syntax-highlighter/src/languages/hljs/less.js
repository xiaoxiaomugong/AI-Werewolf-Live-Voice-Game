import less from "highlight.js/lib/languages/less";
export default less;
