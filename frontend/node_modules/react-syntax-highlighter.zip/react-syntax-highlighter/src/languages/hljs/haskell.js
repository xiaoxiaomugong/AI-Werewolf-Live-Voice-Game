import haskell from "highlight.js/lib/languages/haskell";
export default haskell;
