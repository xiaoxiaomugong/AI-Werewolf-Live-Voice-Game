import lua from "highlight.js/lib/languages/lua";
export default lua;
