import hljs from "highlight.js";
import hljsDefineVue, { definer as vue } from "highlightjs-vue";
hljsDefineVue(hljs);
export default vue;
