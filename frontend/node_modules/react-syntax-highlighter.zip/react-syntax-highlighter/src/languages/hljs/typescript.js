import typescript from "highlight.js/lib/languages/typescript";
export default typescript;
