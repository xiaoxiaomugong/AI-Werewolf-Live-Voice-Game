import asciidoc from "highlight.js/lib/languages/asciidoc";
export default asciidoc;
