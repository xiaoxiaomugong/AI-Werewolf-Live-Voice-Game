import xl from "highlight.js/lib/languages/xl";
export default xl;
