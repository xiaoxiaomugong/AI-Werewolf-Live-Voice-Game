import mathematica from "highlight.js/lib/languages/mathematica";
export default mathematica;
