import q from "highlight.js/lib/languages/q";
export default q;
