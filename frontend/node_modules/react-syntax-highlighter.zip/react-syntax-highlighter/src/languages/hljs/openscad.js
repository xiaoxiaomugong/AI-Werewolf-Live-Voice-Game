import openscad from "highlight.js/lib/languages/openscad";
export default openscad;
