import diff from "highlight.js/lib/languages/diff";
export default diff;
