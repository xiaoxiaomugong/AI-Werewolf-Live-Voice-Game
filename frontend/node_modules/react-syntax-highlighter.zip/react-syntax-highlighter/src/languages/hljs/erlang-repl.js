import erlangRepl from "highlight.js/lib/languages/erlang-repl";
export default erlangRepl;
