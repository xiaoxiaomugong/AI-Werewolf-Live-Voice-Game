import cLike from "highlight.js/lib/languages/c-like";
export default cLike;
