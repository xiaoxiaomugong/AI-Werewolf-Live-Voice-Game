import armasm from "highlight.js/lib/languages/armasm";
export default armasm;
