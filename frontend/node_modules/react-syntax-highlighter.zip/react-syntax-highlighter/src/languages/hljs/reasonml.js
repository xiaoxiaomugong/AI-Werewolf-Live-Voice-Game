import reasonml from "highlight.js/lib/languages/reasonml";
export default reasonml;
