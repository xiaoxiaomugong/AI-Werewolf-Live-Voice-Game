import delphi from "highlight.js/lib/languages/delphi";
export default delphi;
