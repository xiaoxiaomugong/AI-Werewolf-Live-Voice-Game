import twig from "highlight.js/lib/languages/twig";
export default twig;
