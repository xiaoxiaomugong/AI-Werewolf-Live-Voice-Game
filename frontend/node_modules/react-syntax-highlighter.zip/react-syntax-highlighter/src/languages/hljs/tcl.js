import tcl from "highlight.js/lib/languages/tcl";
export default tcl;
