import inform7 from "highlight.js/lib/languages/inform7";
export default inform7;
