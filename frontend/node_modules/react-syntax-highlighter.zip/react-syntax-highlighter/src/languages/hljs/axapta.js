import axapta from "highlight.js/lib/languages/axapta";
export default axapta;
