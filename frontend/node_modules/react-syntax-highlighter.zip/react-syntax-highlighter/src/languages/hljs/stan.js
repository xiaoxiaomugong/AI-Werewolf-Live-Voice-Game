import stan from "highlight.js/lib/languages/stan";
export default stan;
