import sqf from "highlight.js/lib/languages/sqf";
export default sqf;
