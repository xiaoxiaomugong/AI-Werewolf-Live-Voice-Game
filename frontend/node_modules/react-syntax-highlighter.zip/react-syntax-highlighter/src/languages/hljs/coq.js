import coq from "highlight.js/lib/languages/coq";
export default coq;
