import handlebars from "highlight.js/lib/languages/handlebars";
export default handlebars;
