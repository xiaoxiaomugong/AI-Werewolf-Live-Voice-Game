import python from "highlight.js/lib/languages/python";
export default python;
