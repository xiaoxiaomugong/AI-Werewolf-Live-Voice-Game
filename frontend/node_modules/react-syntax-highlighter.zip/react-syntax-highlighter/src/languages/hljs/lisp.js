import lisp from "highlight.js/lib/languages/lisp";
export default lisp;
