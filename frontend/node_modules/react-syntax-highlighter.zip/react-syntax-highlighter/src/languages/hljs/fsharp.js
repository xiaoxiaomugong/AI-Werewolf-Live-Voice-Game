import fsharp from "highlight.js/lib/languages/fsharp";
export default fsharp;
