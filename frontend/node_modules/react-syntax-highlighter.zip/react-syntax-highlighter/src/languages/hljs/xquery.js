import xquery from "highlight.js/lib/languages/xquery";
export default xquery;
