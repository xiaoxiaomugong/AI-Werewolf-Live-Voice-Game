import dust from "highlight.js/lib/languages/dust";
export default dust;
