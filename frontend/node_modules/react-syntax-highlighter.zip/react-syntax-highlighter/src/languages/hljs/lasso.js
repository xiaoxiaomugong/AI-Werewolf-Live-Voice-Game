import lasso from "highlight.js/lib/languages/lasso";
export default lasso;
