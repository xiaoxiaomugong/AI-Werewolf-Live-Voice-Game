import purebasic from "highlight.js/lib/languages/purebasic";
export default purebasic;
