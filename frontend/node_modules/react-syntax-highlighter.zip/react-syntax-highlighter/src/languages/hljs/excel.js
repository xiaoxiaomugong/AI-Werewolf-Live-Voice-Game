import excel from "highlight.js/lib/languages/excel";
export default excel;
