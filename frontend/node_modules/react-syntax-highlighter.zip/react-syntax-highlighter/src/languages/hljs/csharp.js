import csharp from "highlight.js/lib/languages/csharp";
export default csharp;
