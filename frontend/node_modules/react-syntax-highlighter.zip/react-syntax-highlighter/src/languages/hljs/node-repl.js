import nodeRepl from "highlight.js/lib/languages/node-repl";
export default nodeRepl;
