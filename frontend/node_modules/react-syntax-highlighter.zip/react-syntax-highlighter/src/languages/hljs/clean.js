import clean from "highlight.js/lib/languages/clean";
export default clean;
