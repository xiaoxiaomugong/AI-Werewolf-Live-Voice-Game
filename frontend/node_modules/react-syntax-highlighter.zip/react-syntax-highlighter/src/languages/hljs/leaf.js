import leaf from "highlight.js/lib/languages/leaf";
export default leaf;
