import vbnet from "highlight.js/lib/languages/vbnet";
export default vbnet;
