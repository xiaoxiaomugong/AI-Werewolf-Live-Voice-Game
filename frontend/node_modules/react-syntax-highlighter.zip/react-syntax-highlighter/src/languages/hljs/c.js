import c from "highlight.js/lib/languages/c";
export default c;
