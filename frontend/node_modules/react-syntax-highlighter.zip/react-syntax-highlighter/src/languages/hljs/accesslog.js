import accesslog from "highlight.js/lib/languages/accesslog";
export default accesslog;
