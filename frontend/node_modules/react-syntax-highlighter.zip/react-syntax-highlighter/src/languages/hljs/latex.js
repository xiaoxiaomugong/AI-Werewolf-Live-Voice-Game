import latex from "highlight.js/lib/languages/latex";
export default latex;
