import ceylon from "highlight.js/lib/languages/ceylon";
export default ceylon;
