import ruby from "highlight.js/lib/languages/ruby";
export default ruby;
