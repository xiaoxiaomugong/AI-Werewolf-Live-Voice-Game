import arduino from "highlight.js/lib/languages/arduino";
export default arduino;
