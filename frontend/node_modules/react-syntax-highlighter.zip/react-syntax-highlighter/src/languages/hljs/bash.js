import bash from "highlight.js/lib/languages/bash";
export default bash;
