import haxe from "highlight.js/lib/languages/haxe";
export default haxe;
