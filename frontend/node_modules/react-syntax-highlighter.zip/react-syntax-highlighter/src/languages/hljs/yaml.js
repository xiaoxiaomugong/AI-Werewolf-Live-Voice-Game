import yaml from "highlight.js/lib/languages/yaml";
export default yaml;
