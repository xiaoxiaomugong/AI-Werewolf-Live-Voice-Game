import gradle from "highlight.js/lib/languages/gradle";
export default gradle;
