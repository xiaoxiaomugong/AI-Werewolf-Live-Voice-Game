import vim from "highlight.js/lib/languages/vim";
export default vim;
