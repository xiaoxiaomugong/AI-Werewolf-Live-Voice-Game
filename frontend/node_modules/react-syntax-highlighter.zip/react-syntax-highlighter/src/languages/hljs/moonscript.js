import moonscript from "highlight.js/lib/languages/moonscript";
export default moonscript;
