import isbl from "highlight.js/lib/languages/isbl";
export default isbl;
