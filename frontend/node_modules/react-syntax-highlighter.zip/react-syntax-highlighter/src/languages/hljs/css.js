import css from "highlight.js/lib/languages/css";
export default css;
