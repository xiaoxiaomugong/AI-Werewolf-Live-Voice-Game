import scss from "highlight.js/lib/languages/scss";
export default scss;
