import phpTemplate from "highlight.js/lib/languages/php-template";
export default phpTemplate;
