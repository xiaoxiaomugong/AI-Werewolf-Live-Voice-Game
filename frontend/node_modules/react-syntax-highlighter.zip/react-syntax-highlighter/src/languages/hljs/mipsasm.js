import mipsasm from "highlight.js/lib/languages/mipsasm";
export default mipsasm;
