import awk from "highlight.js/lib/languages/awk";
export default awk;
