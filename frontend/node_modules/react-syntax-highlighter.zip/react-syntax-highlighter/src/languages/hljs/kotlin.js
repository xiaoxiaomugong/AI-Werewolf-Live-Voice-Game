import kotlin from "highlight.js/lib/languages/kotlin";
export default kotlin;
