import arcade from "highlight.js/lib/languages/arcade";
export default arcade;
