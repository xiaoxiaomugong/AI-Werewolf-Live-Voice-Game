import vbscript from "highlight.js/lib/languages/vbscript";
export default vbscript;
