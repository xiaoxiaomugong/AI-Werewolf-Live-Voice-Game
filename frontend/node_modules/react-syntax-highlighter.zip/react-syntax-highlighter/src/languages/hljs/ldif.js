import ldif from "highlight.js/lib/languages/ldif";
export default ldif;
