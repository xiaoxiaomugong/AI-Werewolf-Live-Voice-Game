import clojure from "highlight.js/lib/languages/clojure";
export default clojure;
