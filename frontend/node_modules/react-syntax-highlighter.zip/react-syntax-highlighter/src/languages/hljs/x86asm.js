import x86asm from "highlight.js/lib/languages/x86asm";
export default x86asm;
