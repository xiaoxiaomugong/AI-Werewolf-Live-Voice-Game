import applescript from "highlight.js/lib/languages/applescript";
export default applescript;
