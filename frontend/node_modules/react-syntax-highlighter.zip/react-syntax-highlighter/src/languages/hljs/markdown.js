import markdown from "highlight.js/lib/languages/markdown";
export default markdown;
