import gauss from "highlight.js/lib/languages/gauss";
export default gauss;
