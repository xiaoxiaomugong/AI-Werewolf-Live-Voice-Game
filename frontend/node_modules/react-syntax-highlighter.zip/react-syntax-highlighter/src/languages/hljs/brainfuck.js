import brainfuck from "highlight.js/lib/languages/brainfuck";
export default brainfuck;
