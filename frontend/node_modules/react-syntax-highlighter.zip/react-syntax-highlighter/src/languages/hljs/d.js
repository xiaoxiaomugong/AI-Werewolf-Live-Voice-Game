import d from "highlight.js/lib/languages/d";
export default d;
