import r from "highlight.js/lib/languages/r";
export default r;
