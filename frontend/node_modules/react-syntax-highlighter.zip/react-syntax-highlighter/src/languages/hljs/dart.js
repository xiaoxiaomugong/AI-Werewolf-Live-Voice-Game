import dart from "highlight.js/lib/languages/dart";
export default dart;
